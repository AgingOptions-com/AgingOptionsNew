package com.nspl.LegalInfoTestScript;

import com.nspl.agingoptions.webUtil.BaseTest;

public class BeneficiaryLetterTestScript extends BaseTest {
	
	
	

}
